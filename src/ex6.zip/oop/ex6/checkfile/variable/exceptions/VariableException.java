package oop.ex6.checkfile.variable.exceptions;

/**
 * this class is abstract that all the exception in the Variable package inherited
 */
public abstract class VariableException extends Exception {
}
