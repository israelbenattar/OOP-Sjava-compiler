package oop.ex6.checkfile;

import oop.ex6.checkfile.exception.*;
import oop.ex6.checkfile.variable.exceptions.MissingReturnStatementException;

import java.util.*;

public class MethodExtractor {

    private static final String[] savedNames = new String[]{"int", "String", "boolean", "double",
            "char", "void", "final", "if", "while", "true", "false", "return"};

    public int extractMethod(int startingLine, List<String> sJavaFile, ArrayList<String> methodsNames,
                              ArrayList<MethodWrapper> methods) throws CheckFileException {

        Object[] methodLine = extractMethodName(sJavaFile.get(startingLine), startingLine, methodsNames);
        Object[] methodArray = methodLineCounting(startingLine, sJavaFile);
        String methodName = (String) methodLine[0];
        LinkedHashMap methodParam = (LinkedHashMap) methodLine[1];
        int closingLine = (int) methodArray[0];
        ArrayList methodLines = (ArrayList) methodArray[1];

        if (closingLine == 0) {
            throw new UnClosedMethodException(startingLine);

        }else if (!((String) methodLines.get(methodLines.size() - 2)).matches
                ("^\\s*return\\s*;\\s*$")){

            throw new MissingReturnStatementException(closingLine - 1);

        } else {
            MethodWrapper method = new MethodWrapper(startingLine, methodName,methodParam , methodLines);
            methods.add(method);
            return closingLine;
        }
    }

    private Object[] methodLineCounting(int startingLine, List<String> sJavaFile) {
        int closingLine = startingLine;
        int openParenthesis = 1;
        ArrayList<String> methodArr = new ArrayList<>();

        for (int i = startingLine; i < sJavaFile.size(); i++) {
            String line = sJavaFile.get(i);

            if (line.matches("^\\s*(if|while)\\s*\\(.*\\)\\s*\\{\\s*$")) {
                openParenthesis++;

            } else if (line.matches("\\s*\\}\\s*")) {
                openParenthesis--;
            }
            closingLine++;
            methodArr.add(line);

            if (openParenthesis == 0) {
                return new Object[]{closingLine, methodArr};
            }
        }
        return new Object[]{0, methodArr};
    }

    private Object[] extractMethodName(String methodCall, int methodLine, ArrayList<String> methodsNames)
            throws CheckFileException {

        String[] methodCallArr = methodCall.split("\\s*(void |\\(|\\)|,|\\{)\\s*");
        LinkedHashMap<String, Object[]> methodsPerm = new LinkedHashMap<String, Object[]>();
        String methodName = methodCallArr[1];
        LinkedList<String> paramsNames = new LinkedList<>();

        if (methodsNames.contains(methodName)) {
            throw new MethodAlreadyExistException(methodName, methodLine);

        } else if (checkForSavedName(methodName)) {
            throw new SavedNameException(methodName, methodLine);
        }
        for (int i = 2; i < methodCallArr.length; i++) {
            methodParamValidate(methodLine, methodCallArr[i], methodsPerm, paramsNames);
        }
        methodsNames.add(methodName);
        return new Object[]{methodName, methodsPerm};
    }

    private void methodParamValidate(int line, String param, LinkedHashMap<String, Object[]> param1,
                                     LinkedList<String> paramsNames) throws CheckFileException {

        String[] paramArr = param.split(" +");
        String paramName = paramArr[paramArr.length - 1];
        boolean isFinal = (paramArr.length == 3);

        if (checkForSavedName(paramName)) {
            throw new SavedNameException(paramName, line);

        } else if (paramsNames.contains(paramName)) {
            throw new ParamNameExistException(paramName, line);
        }

        paramsNames.add(paramName);
        param1.put(paramName, new Object[]{isFinal, true, paramArr[paramArr.length - 2]});
    }

    private boolean checkForSavedName(String z) {

        for (String name : savedNames) {
            if (name.equals(z)) {
                return true;
            }
        }
        return false;
    }
}
