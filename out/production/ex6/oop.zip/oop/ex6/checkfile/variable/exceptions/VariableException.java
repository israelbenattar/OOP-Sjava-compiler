package oop.ex6.checkfile.variable.exceptions;

public abstract class VariableException extends Exception {
}
