package oop.ex6.checkfile.variable.exceptions;

public class ContainsKayException extends VariableException {

    public ContainsKayException(String var) {
        System.err.println("The variable " +var+ " was already assigned.");
    }
}
