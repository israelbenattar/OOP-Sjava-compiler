package oop.ex6.checkfile.variable.exceptions;

import oop.ex6.checkfile.exception.CheckFileException;

public class MissingReturnStatementException extends CheckFileException {
    public MissingReturnStatementException(int line) {
        System.err.println("Error in line " + line + " : missing return statement.");
    }
}
