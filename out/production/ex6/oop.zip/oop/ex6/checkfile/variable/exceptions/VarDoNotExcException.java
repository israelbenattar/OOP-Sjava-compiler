package oop.ex6.checkfile.variable.exceptions;

public class VarDoNotExcException  extends VariableException {

    public VarDoNotExcException(String varName) {
        System.err.println("Variable " + varName + " was not assigned.");
    }
}
