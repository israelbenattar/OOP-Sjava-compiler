package oop.ex6.checkfile.variable;
import oop.ex6.checkfile.CheckFile;
import oop.ex6.checkfile.variable.exceptions.VariableException;
import oop.ex6.checkfile.variable.exceptions.InValidVarAssignException;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.regex.Pattern;

public class VariableVerifier {

    private intVariable intVar;

    private doubleVariable doubleVar;

    private BooleanVariable booleanVar;

    private StringVariable StringVar;

    private CharVariable charVar;

    private VariableAssignment varAssign;

    private Pattern intPattern;

    private Pattern doublePattern;

    private Pattern stringPattern;

    private Pattern charPattern;

    private Pattern booleanPattern;

    private Pattern fullVariableAssPattern;

    public VariableVerifier() {

        String intStrPattern = "^\\s*(final\\s+)?int\\s+((_\\w|[a-zA-Z])\\w*(\\s*=\\s*(-?\\d+|(_\\w|" +
                "[a-zA-z])\\w*))?\\s*,\\s*)*(_\\w|[a-zA-Z])\\w*(\\s*=\\s*(-?\\d+|(_\\w|[a-zA-Z])\\w*))" +
                "?\\s*;\\s*$";
        this.intPattern = Pattern.compile(intStrPattern);

        String doubleStrPattern ="^\\s*(final\\s+)?double\\s+((_\\w|[a-zA-Z])\\w*(\\s*=\\s*(-?\\d+(\\" +
                ".\\d+)?|(_\\w|[a-z])\\w*))?\\s*,\\s*)*(_\\w|[a-zA-Z])\\w*(\\s*=\\s*(-?\\d+(\\.\\d+)?|" +
                "(_\\w|[a-zA-Z])\\w*))?\\s*;\\s*$";
        this.doublePattern = Pattern.compile(doubleStrPattern);

        String stringStrPattern = "^\\s*(final\\s+)?String\\s+((_\\w|[a-zA-Z])\\w*(\\s*=\\s*(\".*\"|(_\\w" +
                "|[a-zA-Z])\\w*))?\\s*,\\s*)*(_\\w|[a-zA-Z])\\w*(\\s*=\\s*(\".*\"|(_\\w|[a-zA-Z])\\w*))?" +
                "\\s*;\\s*$";
        this.stringPattern = Pattern.compile(stringStrPattern);

        String booleanStrPattern = "^\\s*(final\\s+)?boolean\\s+((_\\w|[a-zA-Z])\\w*(\\s*=\\s*((true|" +
                "false|-?\\d+(.\\d*)?)|(_\\w|[a-zA-Z])\\w*))?\\s*,\\s*)*(_\\w|[a-zA-Z])\\w*(\\s*=\\s*" +
                "((true|false|\\d+(.\\d*)?)|(_\\w|[a-zA-Z])\\w*))?\\s*;\\s*$";
        this.booleanPattern = Pattern.compile(booleanStrPattern);

        String charStrPattern = "^\\s*(final\\s+)?char\\s+((_\\w|[a-zA-Z])\\w*(\\s*=\\s*(\'.?\'|(_\\w|" +
                "[a-zA-Z])\\w*))?\\s*,\\s*)*(_\\w|[a-zA-Z])\\w*(\\s*=\\s*(\'.?\'|(_\\w|[a-zA-Z])\\w*))" +
                "?\\s*;\\s*$";
        this.charPattern = Pattern.compile(charStrPattern);

        String fullVariableAssStrPattern = "^\\s*(_\\w|\\w)\\w*\\s*=\\s*(\".*\"|\'\\.\'|-?\\d+(.\\d)?" +
                "|true|false|(_\\w|[a-z])\\w*)\\s*;\\s*$";
        this.fullVariableAssPattern = Pattern.compile(fullVariableAssStrPattern);

        this.intVar = new intVariable();

        this.doubleVar = new doubleVariable();

        this.booleanVar = new BooleanVariable();

        this.StringVar = new StringVariable();

        this.charVar = new CharVariable();

        this.varAssign = new VariableAssignment();


    }

    public void variableValid(String line, HashMap<String, Object[]> globalVarLst,
                              HashMap<String, Object[]> localVarLst) throws VariableException {

        ArrayList<String> lineLst = lineDivider(line);

        if (intPattern.matcher(line).matches()) {
            intVar.checkValid(lineLst, globalVarLst, localVarLst);

        } else if (doublePattern.matcher(line).matches()) {
            doubleVar.checkValid(lineLst, globalVarLst, localVarLst);

        } else if (booleanPattern.matcher(line).matches()) {
            booleanVar.checkValid(lineLst, globalVarLst, localVarLst);

        } else if (stringPattern.matcher(line).matches()) {
            StringVar.checkValid(lineLst, globalVarLst, localVarLst);

        } else if (charPattern.matcher(line).matches()) {
            charVar.checkValid(lineLst, globalVarLst, localVarLst);

        } else if (fullVariableAssPattern.matcher(line).matches()){
            varAssign.checkValid(lineLst, globalVarLst);
        } else {
            throw new InValidVarAssignException();
        }
    }

    private ArrayList<String> lineDivider(String line) {

        ArrayList<String> output = new ArrayList<String>();
        String[] splitLine = line.split("[ +,;]");
        for (String line1 : splitLine) {
            if (line1.length() != 0) {
                if (line1.contains("=")){
                    String[] var = line1.split("[\'\"=]^");
                    output.addAll(Arrays.asList(var));
                }else{
                    output.add(line1);
                }
            }
        }
        return output;
    }
}
