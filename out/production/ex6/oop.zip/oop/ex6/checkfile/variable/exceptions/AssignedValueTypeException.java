package oop.ex6.checkfile.variable.exceptions;

public class AssignedValueTypeException extends VariableException {
    public AssignedValueTypeException() {
        System.err.println("The type of the assigned value is incorrect.");
    }
}
