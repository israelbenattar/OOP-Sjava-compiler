package oop.ex6.checkfile.variable;

import oop.ex6.checkfile.variable.exceptions.VariableException;

import java.util.ArrayList;
import java.util.HashMap;

public class BooleanVariable extends Variable{

    String MY_TYPE = "boolean";

    void checkValid(ArrayList<String> dividedLine, HashMap<String, Object[]> globalVarLst,
                    HashMap<String, Object[]> localVarLst) throws VariableException {
        super.checkValid(dividedLine, globalVarLst, localVarLst, MY_TYPE);
    }
}
