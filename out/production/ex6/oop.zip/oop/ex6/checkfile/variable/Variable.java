package oop.ex6.checkfile.variable;

import oop.ex6.checkfile.variable.exceptions.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

public class Variable {

    private final String[] unValidNames = new String[]{"int", "String", "boolean", "double",
    "char", "void", "final", "if", "while", "true", "false", "return"};

    /**
     *
     * @param dividedLine
     * @param globalVarLst an map withe the currant variables.
     * @param type the type of the variable.
     * @throws
     */
    public void checkValid(ArrayList<String> dividedLine, HashMap<String, Object[]> globalVarLst,
                           HashMap<String, Object[]> localVarLst, String type)
            throws VariableException {

        boolean isFinal = false;
        boolean assigningValue = false;

        for (int i = 0; i < dividedLine.size(); i++) {
            String part = dividedLine.get(i);

            String variableName = "((_\\w|[a-z])\\w*)";
            if (part.equals("final") && i == 0){
                isFinal = true;

            }else if ((part.equals(type) && isFinal && i == 1)||(part.equals(type) && !isFinal && i ==0)){
                continue;

            }else if (part.matches(variableName)){

                if (!legalVarName(part)) {
                    throw new IllegalVarNameException(part);
                }

                if (localVarLst.containsKey(part)){
                    throw new ContainsKayException(part);
                }

                if (i+1<dividedLine.size() && dividedLine.get(i+1).matches("=")){
                    if (typeMatching(dividedLine.get(i + 2), globalVarLst, type)){
                        throw new AssignedValueTypeException();

                    }else {
                        assigningValue = true;
                        i += 2;
                    }
                }

                if (isFinal && !assigningValue){
                    throw new FinalVarNotAssignedException(part);
                }

                Object[] varValues = new Object[]{isFinal, assigningValue, type};
                localVarLst.put(part, varValues);
                assigningValue = false;
            }
        }
    }

    private boolean legalVarName(String name){
        for (String illegalName: unValidNames){
            if (name.equals(illegalName)){
                return false;
            }
        }
        return true;
    }

    boolean typeMatching(String varValue, HashMap<String, Object[]> varLst,String assignedVarType)
            throws VariableException {
        String[] possibleValueTypes = getPossibleValueType(varValue, varLst);
        for (String possibleType: possibleValueTypes){
            if (possibleType.equals(assignedVarType)){
                return false;
            }

        }
        return true;
    }

    private String[] getPossibleValueType(String varValue, HashMap<String, Object[]> globalVarLst )
            throws VariableException {

        if (varValue.matches("^-?\\d+$")){
            return new String[]{"int", "double", "boolean"};

        }else if (varValue.matches("\".*\"")){
            return new String[]{"String"};

        }else if (varValue.matches("^true|false$")){
            return new String[]{"boolean"};

        }else if (varValue.matches("^-?\\d+.\\d+$")){
            return new String[]{"boolean", "double"};

        }else if(varValue.matches("^\'.?\'")){
            return new String[]{"char"};

        }else if(varValue.matches("^((_\\w|[a-z])\\w*)$")){

            if (globalVarLst.containsKey(varValue)){

                if ((boolean) globalVarLst.get(varValue)[1]) {
                    return new String[]{(String) globalVarLst.get(varValue)[2]};
                }
                throw new VarNotDeclaredException(varValue);

            } else {
                return new String[]{};
            }
        }else {
            return new String[]{};
        }
    }
}
