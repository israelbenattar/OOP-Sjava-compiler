package oop.ex6.checkfile.variable;

import oop.ex6.checkfile.variable.exceptions.VariableException;

import java.util.ArrayList;
import java.util.HashMap;

public class StringVariable extends Variable {

    String MY_TYPE = "String";

    void checkValid(ArrayList<String> dividedLine, HashMap<String, Object[]> globalVarLst,
                    HashMap<String, Object[]> localVarLst) throws VariableException {
        super.checkValid(dividedLine, globalVarLst, localVarLst, MY_TYPE);
    }
}
