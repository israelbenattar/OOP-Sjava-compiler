package oop.ex6.checkfile.variable.exceptions;

public class InValidVarAssignException extends VariableException {
    public InValidVarAssignException() {
        System.err.println("Invalid variable Assignment line.");
    }
}
