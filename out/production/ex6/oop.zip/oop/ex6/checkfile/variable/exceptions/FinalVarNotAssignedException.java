package oop.ex6.checkfile.variable.exceptions;

public class FinalVarNotAssignedException extends VariableException {

    public FinalVarNotAssignedException(String var) {
        System.err.println("The final variable " +var+ " was not assigned at declaration.");
    }
}
