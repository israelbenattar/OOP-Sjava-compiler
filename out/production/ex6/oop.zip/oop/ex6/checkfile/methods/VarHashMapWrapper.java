package oop.ex6.checkfile.methods;

import oop.ex6.checkfile.methods.HashMapFacade;
import oop.ex6.checkfile.methods.Methods;
import oop.ex6.checkfile.methods.ifandwhile.IfAndWhile;

import java.util.HashMap;

public class VarHashMapWrapper extends HashMap<String, Object[]> {

    private HashMapFacade varLst;
    //private VarLstWrapper varLst2 = new VarLstWrapper();


    public VarHashMapWrapper(Methods varLst) {
        this.varLst = varLst;
    }

    public VarHashMapWrapper(IfAndWhile loopVariables) {
        this.varLst = loopVariables;
    }

    @Override
    public boolean containsKey(Object key){
        return varLst.containsKey((String) key);
    }

    @Override
    public Object[] get(Object key){
        return varLst.get((String) key);
    }

    @Override
    public Object[] put(String key, Object[] value){
        varLst.put(key, value);
        return value;
    }

}
