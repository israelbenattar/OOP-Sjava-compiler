package oop.ex6.checkfile.methods;

import oop.ex6.checkfile.MethodWrapper;
import oop.ex6.checkfile.methods.exceptions.MethodException;
import oop.ex6.checkfile.methods.exceptions.UnValidLineException;
import oop.ex6.checkfile.methods.ifandwhile.IfAndWhile;
import oop.ex6.checkfile.variable.VariableVerifier;
import oop.ex6.checkfile.variable.exceptions.VariableException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.regex.Pattern;

public class Methods implements HashMapFacade {

    private final Pattern methodAssignPattern;

    private final Pattern closingBlockPattern;

    private final Pattern variableDeclarationPattern;

    private HashMap<String, Object[]> globalVariable;

    private ArrayList<MethodWrapper> methodsNames;

    private HashMap<String, Object[]> methodVariables;

    private VariableVerifier variableVerifier;

    private MethodCallVerify methodCallVerify;

    private IfAndWhile ifWhileLoop;

    private Pattern variableAssPattern;

    private Pattern commentEmptyLinePattern;

    private Pattern emptyLinePattern;

    private Pattern ifAndWhilePattern;

    private Pattern methodCallPattern;


    public Methods(HashMap<String, Object[]> globalVariable, ArrayList<MethodWrapper> methodsNames,
                   VariableVerifier variableVerifier) {

        this.globalVariable = globalVariable;

        this.methodsNames = methodsNames;

        this.variableVerifier = variableVerifier;

        this.methodCallVerify = new MethodCallVerify(methodsNames);

        String variableAssStrPattern = "^\\s*(_\\w|[a-zA-z])\\w*\\s*=\\s*";
        this.variableAssPattern = Pattern.compile(variableAssStrPattern);

        String ifAndWhileStrPattern = "^\\s*(if|while)\\s*\\(.*\\)\\s*\\{\\s*$";
        this.ifAndWhilePattern = Pattern.compile(ifAndWhileStrPattern);

        String variableDeclarationStrPattern = "^\\s*(final +)?(char|int|String|boolean|double)";
        this.variableDeclarationPattern = Pattern.compile(variableDeclarationStrPattern);

        String commentEmptyReturnLine = "^(//.*|\\s*|\\s*return\\s*;)\\s*$";
        this.commentEmptyLinePattern = Pattern.compile(commentEmptyReturnLine);

        String methodAssPattern = "^\\s*void +[a-zA-Z]\\w*\\s*\\(.*\\)";
        this.methodAssignPattern = Pattern.compile(methodAssPattern);

        String emptyLine = "\\s*";
        this.emptyLinePattern = Pattern.compile(emptyLine);

        String closingBlockStrPattern = "\\s*}\\s*";
        this.closingBlockPattern = Pattern.compile(closingBlockStrPattern);

        String methodCallStrPattern = "^\\s*[a-zA-Z]\\w*\\s*\\( *((-?\\d(.\\d)*|\'.?\'|\".*\"|(_\\w|" +
                "[a-zA-Z]\\w*)\\w*)\\s*(,\\s*(-?\\d(.\\d)*|\'.?\'|\".*\"|(_\\w|\\w[^_])\\w*))*)*\\s*" +
                "\\)\\s*;$";
        this.methodCallPattern = Pattern.compile(methodCallStrPattern);

    }

    public void methodsVerifier(int firstLine, ArrayList<String> method, LinkedHashMap<String, Object[]>
            methodParam) throws VariableException, MethodException {

        this.methodVariables = (HashMap<String, Object[]>) methodParam;
        this.ifWhileLoop = new IfAndWhile(firstLine, method, variableVerifier, methodsNames, new VarHashMapWrapper(this));

        int methodSize = method.size();
        int inMethodLineIndex = 1;

        while (inMethodLineIndex < methodSize) {
            String lineStr = method.get(inMethodLineIndex);

            if (commentEmptyLinePattern.matcher(lineStr).matches() ||
                    emptyLinePattern.matcher(lineStr).matches()) {
                inMethodLineIndex++;

            } else if (variableAssPattern.matcher(lineStr).lookingAt()) {
                variableVerifier.variableValid(lineStr, new VarHashMapWrapper(this), methodVariables);
                inMethodLineIndex++;

            }else if (variableDeclarationPattern.matcher(lineStr).lookingAt()){
                variableVerifier.variableValid(lineStr, new VarHashMapWrapper(this), methodVariables );
                inMethodLineIndex ++;

            } else if (ifAndWhilePattern.matcher(lineStr).lookingAt()) {
                inMethodLineIndex = ifWhileLoop.ifWhileLoopVerifier(inMethodLineIndex);


            } else if (methodCallPattern.matcher(lineStr).lookingAt()) {
                methodCallVerify.validMethod((inMethodLineIndex + firstLine),
                        lineStr, new VarHashMapWrapper(this));
                inMethodLineIndex ++;


            }else if (closingBlockPattern.matcher(lineStr).matches()){
                resetMethodVarLst();
                return;

            } else {
                throw new UnValidLineException(firstLine + inMethodLineIndex);
            }
        }
    }

    private void resetMethodVarLst(){
        this.methodVariables = new HashMap<String, Object[]>();
    }

    @Override
    public boolean containsKey(String key){
        if (methodVariables.containsKey(key)){
            return true;
        }
        return globalVariable.containsKey(key);
    }

    @Override
    public Object[] get(String key) {
        Object[] value = methodVariables.get(key);
        if (value != null){
            return value;
        }
        return globalVariable.get(key);
    }

    @Override
    public Object[] put(String key, Object[] value) {
        return methodVariables.put(key, value);
    }
}
