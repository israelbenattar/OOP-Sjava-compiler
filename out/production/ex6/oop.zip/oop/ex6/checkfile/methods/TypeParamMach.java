package oop.ex6.checkfile.methods;

import java.util.Arrays;
import java.util.HashMap;

public class TypeParamMach {

    private String BOOLEAN = "boolean";

    private String INT = "int";

    private String STRING = "String";

    private String CHAR = "char";

    private String DOUBLE = "double";


    public boolean paramIsType(String type, String param, HashMap<String, Object[]> variables) {

        if (param.matches("^-?\\d+$")) {
            return (type.equals(INT) || type.equals(DOUBLE) || type.equals(BOOLEAN));

        } else if (param.matches("\".*\"")) {
            return (type.equals(STRING));

        } else if (param.matches("^true|false$")) {
            return (type.equals(BOOLEAN));

        } else if (param.matches("^-?\\d+.\\d+$")) {
            return (type.equals(BOOLEAN) || type.equals(DOUBLE));

        } else if (param.matches("^\'.?\'")) {
            return (type.equals(CHAR));

        } else if (param.matches("^((_\\w|[a-z])\\w*)$")) {

            if (variables.containsKey(param)) {
                Object[] objects = variables.get(param);

                if (objects[1].equals(true)) {
                    return  possibleType((String) objects[2], variables);
                }
            } return false;
        } else {
            return false;
        }
    }

    private boolean possibleType(String type, HashMap<String, Object[]> varLst){
        if (type.equals(STRING)){
            return paramIsType("boolean", "\"a\"", varLst);
        }else if (type.equals(CHAR)){
            return paramIsType("boolean", "\'a\'", varLst);
        }else {
            return paramIsType("boolean", "0", varLst);

        }
    }
}
