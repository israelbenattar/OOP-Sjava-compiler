package oop.ex6.checkfile.methods.exceptions;

public class WrongConditionTypeException extends MethodException {

    public WrongConditionTypeException(int line, String param) {
        System.err.println("Error in line " +line+ " : the param " +param+ " is not boolean.");
    }
}
