package oop.ex6.checkfile.methods.exceptions;

public class UnClosedLoopException extends MethodException {
    public UnClosedLoopException(int line) {
        System.err.println("Error in line " + line + " : the loop is unclosed.");
    }
}
