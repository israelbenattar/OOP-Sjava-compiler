package oop.ex6.checkfile.methods.ifandwhile;

import oop.ex6.checkfile.methods.TypeParamMach;
import oop.ex6.checkfile.methods.exceptions.*;

import java.util.Arrays;
import java.util.HashMap;
import java.util.regex.Pattern;

public class IfAndWhileStatementVerify {

    private Pattern ifAndWhileFullPattern;

    private TypeParamMach typeMatcher;

    public IfAndWhileStatementVerify() {

        String ifAndWhileFullStr = "^\\s*(if|while)\\s*\\(\\s*((true|false|-?\\d+(.\\d*)?)|(_\\w|[a-z])\\w*\\s*" +
                "((\\|\\||\\&\\&)\\s*((true|false|-?\\d+(.\\d*)?)|(_\\w|[a-z])\\w*)\\s*)*)+\\s*\\)\\s*\\{\\s*$";
        this.ifAndWhileFullPattern = Pattern.compile(ifAndWhileFullStr);

        this.typeMatcher = new TypeParamMach();

    }

    public void ifAndWhileVerify(int lineIndex, String ifWhileStatement, HashMap<String, Object[]> variables)
            throws MethodException {
        if (!ifAndWhileFullPattern.matcher(ifWhileStatement).matches()) {
            throw new UnValidParameterException(lineIndex);
        } else {
            String[] statementArr = ifWhileStatement.split("\\s*(\\(|\\)|(\\|\\|)|(\\&\\&)|\\{)\\s*");
            for (int paramIndex = 1; paramIndex < statementArr.length; paramIndex++) {
                String param = statementArr[paramIndex];
                if (!typeMatcher.paramIsType("boolean", param, variables)) {
                    throw new WrongConditionTypeException(lineIndex, param);
                }
            }
        }

    }
}
