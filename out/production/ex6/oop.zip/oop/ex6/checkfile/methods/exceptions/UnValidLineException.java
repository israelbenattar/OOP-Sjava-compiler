package oop.ex6.checkfile.methods.exceptions;

import oop.ex6.checkfile.methods.Methods;

public class UnValidLineException extends MethodException {

    public UnValidLineException(int line) {
        System.err.println("Error in line " + line + " : the line is invalid S-java line.");
    }
}
