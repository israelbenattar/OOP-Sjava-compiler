package oop.ex6.checkfile.methods.exceptions;

public class UnValidParameterException extends MethodException {
    public UnValidParameterException(int line) {
        System.err.println("Error in line " + (line+1) + " : inValid condition.");
    }
}
