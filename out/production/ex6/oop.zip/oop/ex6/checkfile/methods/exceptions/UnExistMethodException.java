package oop.ex6.checkfile.methods.exceptions;

public class UnExistMethodException extends MethodException{

    public UnExistMethodException(String methodName, int lineNumber) {
        System.err.println("error in line "+lineNumber+" : The method "+ methodName +" don't exist.");
    }
}
