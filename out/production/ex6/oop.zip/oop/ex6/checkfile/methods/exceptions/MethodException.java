package oop.ex6.checkfile.methods.exceptions;

public class MethodException extends Exception {

}
