package oop.ex6.checkfile.methods.ifandwhile;

import oop.ex6.checkfile.methods.HashMapFacade;
import oop.ex6.checkfile.MethodWrapper;
import oop.ex6.checkfile.methods.VarHashMapWrapper;
import oop.ex6.checkfile.methods.MethodCallVerify;
import oop.ex6.checkfile.methods.exceptions.MethodException;
import oop.ex6.checkfile.methods.exceptions.UnClosedLoopException;
import oop.ex6.checkfile.methods.exceptions.UnValidLineException;
import oop.ex6.checkfile.variable.VariableVerifier;
import oop.ex6.checkfile.variable.exceptions.VariableException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.Pattern;

public class IfAndWhile implements HashMapFacade {

    private final Pattern ifAndWhileFullPattern;

    private final IfAndWhileStatementVerify ifAndWhileStatementVerify;

    private final ArrayList<MethodWrapper> sJavaMethods;

    private final Pattern variableDeclarationPattern;

    private ArrayList<String> method;

    private HashMap<String, Object[]> globalVariable;

    private HashMap<String, Object[]> loopVariables;

    private int methodFirstLineIndex;

    private final Pattern variableAssPattern;

    private final Pattern commentEmptyReturnLinePattern;

    private final Pattern methodCallPattern;

    private final Pattern closingBlockPattern;

    private VariableVerifier variableVerifier;

    private MethodCallVerify methodCallVerify;

    public IfAndWhile(int methodFirstLineIndex, ArrayList<String> method, VariableVerifier variableVerifier,
                      ArrayList<MethodWrapper> methods, HashMap<String, Object[]> globalVariable){

        this.method = method;

        this.sJavaMethods = methods;

        this.loopVariables = new HashMap<>();

        this.variableVerifier = variableVerifier;

        this.globalVariable = globalVariable;

        this.methodFirstLineIndex = methodFirstLineIndex;

        this.ifAndWhileStatementVerify = new IfAndWhileStatementVerify();

        this.methodCallVerify = new MethodCallVerify(methods);

        String methodCallStrPattern = "^\\s*[a-zA-Z]\\w*\\s*\\( *((-?\\d(.\\d)*|\'.?\'|\".*\"|(_\\w|" +
                "[a-zA-Z]\\w*)\\w*)\\s*(,\\s*(-?\\d(.\\d)*|\'.?\'|\".*\"|(_\\w|\\w[^_])\\w*))*)*\\s*" +
                "\\)\\s*;$";
        this.methodCallPattern = Pattern.compile(methodCallStrPattern);

        String variableAssStrPattern = "^\\s(_\\w|\\w)\\w*\\s*=\\s*";
        this.variableAssPattern = Pattern.compile(variableAssStrPattern);

        String variableDeclarationStrPattern = "^\\s*(final\\s+)?(char|int|String|boolean|double)";
        this.variableDeclarationPattern = Pattern.compile(variableDeclarationStrPattern);

        String commentEmptyReturnLine = "(^//.*|\\s*(return\\s*;)?)$";
        this.commentEmptyReturnLinePattern = Pattern.compile(commentEmptyReturnLine);

        String closingBlockStrPattern = "\\s*}\\s*";
        this.closingBlockPattern = Pattern.compile(closingBlockStrPattern);

        String ifAndWhileFullStr = "^\\s*(if|while)\\s*\\(\\s*((true|false|-?\\d+(.\\d*)?)|(_\\w|[a-z])" +
                "\\w*\\s*((\\|\\||\\&\\&)\\s*((true|false|-?\\d+(.\\d*)?)|(_\\w|[a-z])\\w*)\\s*)*)*\\s*" +
                "\\)\\s*\\{\\s*$";
        this.ifAndWhileFullPattern = Pattern.compile(ifAndWhileFullStr);
    }

    public int ifWhileLoopVerifier(int inMethodIndex)
            throws VariableException, MethodException {


        ifAndWhileStatementVerify.ifAndWhileVerify(methodFirstLineIndex + inMethodIndex,
                method.get(inMethodIndex), new VarHashMapWrapper(this));

        int currentMethodLine = inMethodIndex + 1;

        while (currentMethodLine < method.size()) {
            String line = method.get(currentMethodLine);

            if (commentEmptyReturnLinePattern.matcher(line).lookingAt()) {
                currentMethodLine++;

            } else if (variableAssPattern.matcher(line).lookingAt()) {
                variableVerifier.variableValid(line, new VarHashMapWrapper(this),
                        loopVariables);
                currentMethodLine++;

            } else if (variableDeclarationPattern.matcher(line).lookingAt()) {
                variableVerifier.variableValid(line, new VarHashMapWrapper(this),
                        loopVariables);
                currentMethodLine++;

            }else if (ifAndWhileFullPattern.matcher(line).lookingAt()) {
                IfAndWhile ifAndWhileLoop = new IfAndWhile(methodFirstLineIndex, method, variableVerifier,
                        sJavaMethods, new VarHashMapWrapper(this));
                currentMethodLine = ifAndWhileLoop.ifWhileLoopVerifier(currentMethodLine);

            } else if (methodCallPattern.matcher(line).lookingAt()){
                methodCallVerify.validMethod((currentMethodLine + methodFirstLineIndex)
                        ,line, new VarHashMapWrapper((this)));
                currentMethodLine ++;

            } else if (closingBlockPattern.matcher(line).matches()){
                currentMethodLine ++;
                resetLoopVarHashMap();
                return currentMethodLine;

            }else {
                System.out.println(line);
                throw new UnValidLineException(methodFirstLineIndex + currentMethodLine);
            }
        }
        throw new UnClosedLoopException(methodFirstLineIndex + currentMethodLine);
    }

    private void resetLoopVarHashMap(){
        this.loopVariables = new HashMap<String, Object[]>();
    }


    @Override
    public boolean containsKey(String key) {
        boolean loopContainKey = loopVariables.containsKey(key);
        if (loopContainKey){
            return true;
        }
        return globalVariable.containsKey(key);
    }

    @Override
    public Object[] get(String key) {
        Object[] value = loopVariables.get(key);
        if (value != null){
            return value;
        }
        return globalVariable.get(key);
    }

    @Override
    public Object[] put(String key, Object[] value) {
        return loopVariables.put(key, value);
    }
}
