package oop.ex6.checkfile.methods;

import oop.ex6.checkfile.MethodWrapper;
import oop.ex6.checkfile.methods.exceptions.UnExistMethodException;

import java.util.*;


public class MethodCallVerify {

    private final TypeParamMach typeMacher;

    private LinkedHashMap<String, Object[]> parameters;

    private ArrayList<MethodWrapper> methodWrapper;

    private HashMap<String, Object[]> hashMapVariables;

    private int FIRST = 0;

    private ArrayList<String> methodType;


    public MethodCallVerify(ArrayList<MethodWrapper> methods) {

        this.methodWrapper = methods;

        this.typeMacher = new TypeParamMach();


    }

    private ArrayList<String> getParamFromWrapper(String methodName, HashMap<String, Object[]> hashMapVariables) {
        this.hashMapVariables = hashMapVariables;
        ArrayList<String> param = new ArrayList<>();

        for (MethodWrapper methodWrap : methodWrapper) {
            if (methodWrap.getName().equals(methodName)) {
                this.parameters = methodWrap.getParam();
            }
        }
        if (this.parameters != null)
            parameters.forEach((name, array) -> {
                param.add((String) array[2]);
            });
        return param;
    }


    private boolean existMethod(String method) {
        for (MethodWrapper methodWrap : methodWrapper) {
            if (methodWrap.getName().equals(method)) {
                return true;
            }
        }
        return false;
    }


    private TreeMap<String, ArrayList<String>> extractNameAndParam(String methodLine) {
        String[] words = methodLine.split("\\s*,\\s*|\\s*\\(\\s*|\\s*\\)\\s*|\\s*;\\s*");
        String methodName = words[FIRST].stripLeading();
        ArrayList<String> param = new ArrayList<>();
        TreeMap<String, ArrayList<String>> method = new TreeMap<>();
        int length = words.length;
        int index = 1;

        while (index < length) {
            param.add(words[index]);
            index++;
        }

        method.put(methodName, param);

        return method;
    }


    private Boolean validParamMethod(ArrayList<String> typeList, ArrayList<String> paramList) {
        if (typeList.size() != paramList.size()) {
            return false;
        }
        int size = paramList.size();
        int index = 0;
        while (index < size) {
            if (!typeMacher.paramIsType(typeList.get(index), paramList.get(index), hashMapVariables))
                return false;
            index++;
        }
        return true;
    }


    public boolean validMethod(int line, String methodLine, HashMap<String, Object[]> hashMapVariables)
            throws UnExistMethodException {
        //first we split the line

        TreeMap<String, ArrayList<String>> methodNameParam = extractNameAndParam(methodLine);

        String methodName = methodNameParam.firstKey();
        ArrayList<String> param = methodNameParam.get(methodName);

        //making sure that the method is exist
        if (existMethod(methodName)) {
            this.methodType = getParamFromWrapper(methodName, hashMapVariables);

            //making sure that the param are valid
            return (validParamMethod(methodType, param));

        }

        throw new UnExistMethodException(methodName, line);
    }
}

