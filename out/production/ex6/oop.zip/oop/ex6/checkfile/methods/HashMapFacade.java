package oop.ex6.checkfile.methods;

public interface HashMapFacade {

    boolean containsKey(String key);

    Object[] get(String key);

    Object[] put(String key, Object[] value);

}
