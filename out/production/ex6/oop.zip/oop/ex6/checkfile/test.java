package oop.ex6.checkfile;

import oop.ex6.checkfile.variable.VariableVerifier;
import oop.ex6.checkfile.variable.exceptions.VariableException;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class test {

//    public static void main(String[] args) throws VariableException {
//        String ifWhileStatement = "if ( acv || b && c ) {";
//        String[] statementArr = ifWhileStatement.split(" +(\\(|\\)|(\\|\\|)|(\\&\\&)|\\{) *");
//        System.out.println(Arrays.toString(statementArr));
//    }

}
