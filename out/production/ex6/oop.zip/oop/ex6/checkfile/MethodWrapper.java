package oop.ex6.checkfile;

import java.util.ArrayList;
import java.util.LinkedHashMap;

public class MethodWrapper extends ArrayList<String> {

    private int startingLine;

    private String methodName;

    private LinkedHashMap<String, Object[]> methodParam;

    private ArrayList<String> methodArray;

    public MethodWrapper(int startingLine , String methodName, LinkedHashMap<String, Object[]> methodParam,
                         ArrayList<String> methodArray) {

        this.startingLine = startingLine;

        this.methodName = methodName;

        this.methodParam = methodParam;

        this.methodArray = methodArray;

    }

    public ArrayList getArray(){
        return this.methodArray;
    }

    public int getStartingLine(){
        return this.startingLine;
    }

    public LinkedHashMap<String, Object[]> getParam(){
        return this.methodParam;
    }

    public String getName(){
        return methodName;
    }
}
