package oop.ex6.checkfile;

import oop.ex6.checkfile.exception.*;
import oop.ex6.checkfile.methods.exceptions.MethodException;
import oop.ex6.checkfile.variable.VariableVerifier;
import oop.ex6.checkfile.methods.Methods;
import oop.ex6.checkfile.variable.exceptions.VariableException;

import java.util.*;
import java.util.regex.Pattern;

public class CheckFile {

    private MethodExtractor methodExtractor;

    private VariableVerifier variableVerifier;

    private Methods methodVerifier;

    private HashMap<String, Object[]> variables;

    private ArrayList<String> methodsNames;

    private ArrayList<MethodWrapper> methods;

    private Pattern commentLinePattern;

    private Pattern methodPattern;

    private Pattern variableAssPattern;

    private Pattern emptyLinePattern;

    private Pattern variablePattern;


    public CheckFile() {

        this.variables = new HashMap<String, Object[]>();

        this.methodsNames = new ArrayList<String>();

        this.methods = new ArrayList<MethodWrapper>();

        this.variableVerifier = new VariableVerifier();

        this.methodExtractor = new MethodExtractor();

        String commentLine = "^//.*$";
        this.commentLinePattern = Pattern.compile(commentLine);

        String emptyLine = " *";
        this.emptyLinePattern = Pattern.compile(emptyLine);

        String fullMethodStrPattern = "^\\s*void\\s+([a-zA-Z]\\w*)\\s*(\\( *\\)|\\(\\s*((final\\s+)?" +
                "(char|int|String|boolean|double)\\s+((_\\w|[a-z])\\w*))(\\s*,\\s*(final\\s+)?(char|" +
                "int|String|boolean|double)\\s+((_\\w|[a-z])\\w*))*\\s*\\))\\s*\\{\\s*$";
        this.methodPattern = Pattern.compile(fullMethodStrPattern);

        String variableStrPattern = "^\\s*((final +)?(char|int|String|boolean|double)|" +
                "(_\\w|\\w)\\w*\\s*=\\s*)";
        this.variablePattern = Pattern.compile(variableStrPattern);

        String variableAssStrPattern = "^\\s*(_\\w|\\w)\\w*\\s*=\\s*";
        this.variableAssPattern = Pattern.compile(variableAssStrPattern);
    }

    public void checkValid(List<String> sJavaFile) {
        int line = 0;
        try {
            while (line < sJavaFile.size()) {
                String lineStr = sJavaFile.get((line));

                if (variablePattern.matcher(lineStr).lookingAt() ||
                        variableAssPattern.matcher(lineStr).lookingAt()) {
                    variableVerifier.variableValid(lineStr, variables, variables);
                    line++;

                } else if (methodPattern.matcher(lineStr).lookingAt()) {
                    line = methodExtractor.extractMethod(line, sJavaFile, methodsNames, methods);

                } else if (commentLinePattern.matcher(lineStr).matches() ||
                        emptyLinePattern.matcher(lineStr).matches()) {
                    line++;

                } else {
                    throw new InvalidLineException(line);
                }
            }
            verifyMethods();
        } catch (VariableException | CheckFileException | MethodException e) {
            System.out.println("1");
            return;
        }
        System.out.println("0");
    }

    private void verifyMethods() throws VariableException, MethodException {
        this.methodVerifier = new Methods(variables, methods, variableVerifier);
        for (MethodWrapper method : methods) {
            methodVerifier.methodsVerifier(method.getStartingLine(), method.getArray(), method.getParam());
        }

    }
}