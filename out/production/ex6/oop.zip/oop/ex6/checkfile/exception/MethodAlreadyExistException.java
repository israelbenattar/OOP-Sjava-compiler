package oop.ex6.checkfile.exception;

public class MethodAlreadyExistException extends  CheckFileException {

    public MethodAlreadyExistException(String methodName, int line) {
        System.err.println("error in line " +line+" : a method named " + methodName + " already exist.");
    }
}
