package oop.ex6.checkfile.exception;

public class InvalidLineException extends CheckFileException {
    public InvalidLineException(int line) {
        System.err.println("Error in line " + (line+1) + " : invalid sJava line.");
    }
}
