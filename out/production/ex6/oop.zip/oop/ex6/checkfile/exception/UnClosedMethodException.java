package oop.ex6.checkfile.exception;

public class UnClosedMethodException extends CheckFileException {
    public UnClosedMethodException(int line)
    {
        System.err.println("Error in line " + line + " : The method that start in this line is unclosed.");
    }
}
