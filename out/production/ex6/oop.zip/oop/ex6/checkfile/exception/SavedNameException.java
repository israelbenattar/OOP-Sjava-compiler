package oop.ex6.checkfile.exception;

public class SavedNameException extends CheckFileException {
    public SavedNameException(String methodName, int line) {
        System.err.println("error in line " + line + " : the name " + methodName + " is a saved name.");
    }
}
