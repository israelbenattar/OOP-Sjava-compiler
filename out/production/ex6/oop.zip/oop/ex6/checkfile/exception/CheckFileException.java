package oop.ex6.checkfile.exception;

public class CheckFileException extends Exception {
}
