package oop.ex6.checkfile.exception;

public class ParamNameExistException extends CheckFileException {
    public ParamNameExistException(String paramName, int line) {
        System.err.println("error in line " + line + " : the param name " +paramName+" already exist." );
    }
}
