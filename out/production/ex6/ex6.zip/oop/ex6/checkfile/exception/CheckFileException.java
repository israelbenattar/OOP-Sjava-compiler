package oop.ex6.checkfile.exception;

/**
 * this class is abstract that all the Exception in the checkFile package inherited
 */

public abstract class CheckFileException extends Exception {

}
