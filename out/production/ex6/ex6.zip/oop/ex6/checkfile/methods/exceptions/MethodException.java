package oop.ex6.checkfile.methods.exceptions;

/**
 * this class is abstract that all the exception in the Method package inherited
 */
public abstract class MethodException extends Exception {

}
