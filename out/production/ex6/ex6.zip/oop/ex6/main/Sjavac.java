package oop.ex6.main;

import oop.ex6.checkfile.CheckFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

public class Sjavac {

    public static void main(String[] args){
        CheckFile myChecker = new CheckFile();
        try {
            List<String> sJavaLines = Files.readAllLines(Paths.get(args[0]));
            myChecker.checkValid(sJavaLines);
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println(2);
        }
    }
}
